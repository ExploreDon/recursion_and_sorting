# mypackage

This package was built to provide functions that show different types of sorting and recursion functionalities and uses.

## Build this package locally

`python setup.py sdist`

## installing this package from GitHub
`pip install git+https://github.com/siphe2009/example-python-package.git`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/siphe2009/example-python-package.git`
